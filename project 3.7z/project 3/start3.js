

var gl;
var points = [];
var points2=[];
var carpoints=[];
var carcolors=[];
var colors2=[];
var colors=[];

var wallcord=[	vec4(-35,0,5,1.0),
				vec4(-35,15,5,1.0),
				vec4(-35,15,-35,1.0),
				vec4(-35,0,-35,1.0),
				vec4(35,0,5,1.0),
				vec4(35,15,5,1.0),
				vec4(35,15,-35,1.0),
				vec4(35,0,-35,1.0),
				//////strip
				vec4(-4,0.01,5,1.0),
				vec4(-4,0.01,-35,1.0),
				vec4(-2,0.01,5,1.0),
				vec4(-2,0.01,-35,1.0),
				
				vec4(4,0.01,5,1.0),
				vec4(4,0.01,-35,1.0),
				vec4(2,0.01,5,1.0),
				vec4(2,0.01,-35,1.0),
				
				];
var base=[	vec4([-35,0,-35,1.0]),
			vec4([35,0,-35,1.0]),
			vec4([35,0,5,1.0]),
			vec4([-35,0,5,1.0])];
var wall=[];
var wallcolors=[];
var vertices=[vec4(0.0,0.0,((-1.0)-0.5),4),
				vec4(0.0,0.942809,((0.333333)-0.5),4),
				vec4(-0.816497,-0.471405,((0.333333)-0.5),4),
				vec4(0.816497,-0.471405,((0.333333)-0.5),4),
				];
var carv = [
        vec4( -0.1,  0.01,  0.1,1 ),
        vec4( -0.1,  0.1,  0.1,1 ),
        vec4(  0.1,  0.1,  0.1,1 ),
        vec4(  0.1,  0.01,  0.1,1 ),
        vec4( -0.1,  0.01, -0.1,1 ),
        vec4( -0.1,  0.1, -0.1,1 ),
        vec4(  0.1,  0.1, -0.1,1 ),
        vec4(  0.1,  0.01, -0.1,1 )
		];
var carv2=[
		vec4( -0.08,  0.11,  0.08,1 ),
        vec4( -0.08,  0.2,  0.08,1 ),
        vec4(  0.08,  0.2,  0.08,1 ),
        vec4(  0.08,  0.11,  0.08,1 ),
        vec4( -0.08,  0.11, -0.08,1 ),
        vec4( -0.08,  0.2, -0.08,1 ),
        vec4(  0.08,  0.2, -0.08,1 ),
        vec4(  0.08,  0.11, -0.08,1 )
		];
		

var ang=0.0;
var t=0;
var l=0.1;
var program;
var green=vec4(1.0,1.0,1.0,0.8);
var red=vec4(1.0,0.0,0.0,1.0);
var black=vec4(1,1,1,1.0);

var camx=0;
var camy=1.5;
var camz=1.1;

var a=0;
var b=0;
var c=-10;

var left=-5.0;
var right=5.0;
var near=-100;
var far=40;
var bottom=-5.0;
var to=5.0;

var spherez=0.5;
var spherex=0;

var vBuffer;
var cBuffer;
var tBuffer;
var tBuffer1;
var map = {37: false, 38: false, 39: false, 40:false};

///////////////////////////////for texture
var texCoordsArray = [];
var texCoordsArray1 = [];
var cartex=[];
var texture;
var texture1;
var texture2;
var image;
var image1;
var image2;
var flag=0;
var texCoord = [
    vec2(0, 0),
    vec2(0, 1),
    vec2(1, 1),
    vec2(1, 0)
];
///shading
var normals1 = [];
var normals2 = [];
var normals3 = [];
var nbufferId1;
var nbufferId2;
var nbufferId3;
   
var lightPosition = vec4(1.0, 10.0, -10.0, 0.0 );
var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0 );
var lightDiffuse = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpecular = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightw = 1.0;
// MAterial 1
var materialAmbient1 = vec4( 1.0, 0.0, 1.0, 1.0 );
var materialDiffuse1 = vec4( 1.0, 0.8, 0.0, 1.0 );
var materialSpecular1 = vec4( 1.0, 1.0, 1.0, 1.0 );
var materialShininess1 = 200.0;

var ambientProduct1 = mult(lightAmbient, materialAmbient1);
var diffuseProduct1 = mult(lightDiffuse, materialDiffuse1);
var specularProduct1 = mult(lightSpecular, materialSpecular1);

// MAterial 2
var materialAmbient2 = vec4( 1.0, 1.0, 0.0, 1.0 );
var materialDiffuse2 = vec4( 1.0, 0.0, 0.8, 1.0 );
var materialSpecular2 = vec4( 1.0, 0.0, 0.8, 1.0 );
var materialShininess2 = 2.0;

var ambientProduct2 = mult(lightAmbient, materialAmbient2);
var diffuseProduct2 = mult(lightDiffuse, materialDiffuse2);
var specularProduct2 = mult(lightSpecular, materialSpecular2);

// MAterial 3
var materialAmbient3 = vec4( 0.0, 1.0, 1.0, 1.0 );
var materialDiffuse3 = vec4( 0.0, 0.8, 1.0, 1.0 );
var materialSpecular3 = vec4( 0.0, 0.8, 1.0, 1.0 );
var materialShininess3 = 600.0;

var ambientProduct3 = mult(lightAmbient, materialAmbient3);
var diffuseProduct3 = mult(lightDiffuse, materialDiffuse3);
var specularProduct3 = mult(lightSpecular, materialSpecular3);


var ctm;
var ambientColor, diffuseColor, specularColor;



////////////////////////////////////////////////
// What function should execute first should be tagged with window.onload.
window.onload = function init()
{
    var canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

// One of the many ways of specifying vertices.    
        
    //  Configure WebGL
	
    gl.viewport( 0, 0, canvas.width, canvas.height ); // Sets the camera/viewer.
    gl.clearColor( 1.0, 0.0, 1.0, 1.0 );
    
    //  Load shaders and initialize attribute buffers
    gl.enable(gl.DEPTH_TEST);
    program = initShaders( gl, "vertex-shader", "fragment-shader" ); // Compile vertex and fragment shaders
    gl.useProgram( program );
    
	sine();
	car(carv);
	//car2(carv2);
	makewall(wallcord);
	
	image  = document.getElementById("sky");
	image1 = document.getElementById("road");
	image2 = document.getElementById("car");
    configureTexture( image );
	configureTexture1( image1 );
	configureTexture2( image2 );
	
	///////////////////////////////
	
	
	
    // Load the data into the GPU
	vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(wall), gl.STATIC_DRAW );

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition ); // Enables vertex attributes in the local shader.
	
    tBuffer1 = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer1 );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW );

    var vTexCoord = gl.getAttribLocation( program, "vTexCoord" );
    gl.vertexAttribPointer( vTexCoord, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vTexCoord );
	
	tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray1), gl.STATIC_DRAW );

    var vTexCoord = gl.getAttribLocation( program, "vTexCoord" );
    gl.vertexAttribPointer( vTexCoord, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vTexCoord );
	
	/*cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );

    var vColor = gl.getAttribLocation( program, "vColor" );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vColor ); // Enables vertex attributes in the local shader.
	*/
	nbufferId1 = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId1 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals3), gl.STATIC_DRAW );

    var vNormal = gl.getAttribLocation( program, "vNormal" );
    gl.vertexAttribPointer( vNormal, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vNormal );
	
	nbufferId2 = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId2 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals2), gl.STATIC_DRAW );

    var vNormal = gl.getAttribLocation( program, "vNormal" );
    gl.vertexAttribPointer( vNormal, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vNormal );
	
	nbufferId3 = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId3 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals1), gl.STATIC_DRAW );

    var vNormal = gl.getAttribLocation( program, "vNormal" );
    gl.vertexAttribPointer( vNormal, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vNormal );
	
	ambProdLoc = gl.getUniformLocation(program, "ambientProduct"); 
	difProdLoc = gl.getUniformLocation(program, "diffuseProduct"); 
	specProdLoc = gl.getUniformLocation(program, "specularProduct"); 
	shininessLoc = gl.getUniformLocation(program, "shininess"); 

	lightPositionLoc = gl.getUniformLocation(program, "lightPosition");  
	gl.uniform4fv(lightPositionLoc,flatten(lightPosition));     
	
	document.addEventListener('keypress',onkeydown,false);
	document.addEventListener('keyup',onkeyup,false );
    render(); // Function that deals with drawing the image.
};



function sine(){
	var z=5;
	var x1=0;
	var x2=0;
	var x3=0;
	var x4=0;	
	for(var i=0;i<100;i++){
		var z1=z;
		z=z - 0.4;
		
		x1=Math.sin(z1)-0.7;
		x2=Math.sin(z)-0.7;
		x3=0.7+Math.sin(z);
		x4=0.7+Math.sin(z1);
		
		points2.push([x1,0.0,z1,1.0]);
		points2.push([x2,0.0,z,1]);
		points2.push([x3,0.0,z,1.0]);
		points2.push([x3,0.0,z,1.0]);
		points2.push([x4,0.0,z1,1.0]);
		points2.push([x1,0.0,z1,1.0]);
		texCoordsArray1.push(texCoord[0]);
		texCoordsArray1.push(texCoord[1]);
		texCoordsArray1.push(texCoord[2]);
		texCoordsArray1.push(texCoord[2]);
		texCoordsArray1.push(texCoord[3]);
		texCoordsArray1.push(texCoord[0]);
		colors.push(black);
		colors.push(black);
		colors.push(black);
		colors.push(black);
		colors.push(black);
		colors.push(black);
		normals1.push([x1,0.0,z1,1.0]);
		normals1.push([x2,0.0,z,1]);
		normals1.push([x3,0.0,z,1.0]);
		normals1.push([x3,0.0,z,1.0]);
		normals1.push([x4,0.0,z1,1.0]);
		normals1.push([x1,0.0,z1,1.0]);
	}	
}

function check(z, x1, x2,x){
	var xmid=Math.sin(z);
	var left=Math.sin(z)-0.7;
	var right=Math.sin(z)+0.7;
	
	if(z<-35){
		window.alert("Finished, you win");
		window.location.reload();
	}
	
	if((left-x1)>0){
		//console.log(xmid);
		//console.log(x1);
		window.alert("You are OUT"+ "\nYour score is :"+(z*10)/(-1));
		var delay=100000;
		setTimeout(function(){
		
		}, delay);
		window.location.reload();
	}
	
	
	if((right-x2)<0){
		//console.log(xmid);
		//console.log(x2);
		window.alert("You are OUT"+ "\nYour score is :"+(z*10)/(-1));
		
		var delay=100000;
		setTimeout(function(){
			
		}, delay);
		window.location.reload();
	}
	
	
	
}
function onkeydown(e) {
		
		if (e.keyCode in map) {
			map[e.keyCode] = true;
			if(map[37] ){
				a=a-0.157142857;
				spherex=spherex -0.1;
				camx=camx-0.05;
				ang=t;
			}
			if (map[39]) {
				a=a+0.157142857;
				spherex=spherex +0.1;
				camx=camx+0.05;
				ang=-t;
			}
			if(map[38]){
				camz=camz-0.1;
				c=c-0.1;
				near=near+0.1;
				far=far-0.1;
				spherez=spherez -0.1;
			}
			if(map[40]){
				camz=camz+0.1;
				c=c+0.1;
				near=near-0.1;
				far=far+0.1;
				spherez=spherez +0.1;
			}
			if(map[37] && map[38]){
				a=a-0.157142857;
				spherex=spherex -0.1;
				///////////////////////////////////
				camz=camz-0.1;
				c=c-0.1;
				near=near+0.1;
				far=far-0.1;
				spherez=spherez -0.1;
				camx=camx-0.05;
				ang=t;
			}
			if(map[38] && map[39]){
				camz=camz-0.1;
				c=c-0.1;
				near=near+0.1;
				far=far-0.1;
				spherez=spherez -0.1;
				////////////////////////////////////////////////////
				a=a+0.157142857;
				spherex=spherex +0.1;
				camx=camx+0.05;
				ang=-t;
			}
			if(map[37] && map[40]){
				a=a-0.157142857;
				spherex=spherex -0.1;
				camz=camz+0.1;
				c=c+0.1;
				near=near-0.1;
				far=far+0.1;
				spherez=spherez +0.1;
				camx=camx-0.05;
				ang=t;
			}
			if(map[39] && map[40]){
				a=a+0.157142857;
				spherex=spherex +0.1;
				camz=camz+0.1;
				c=c+0.1;
				near=near-0.1;
				far=far+0.1;
				spherez=spherez +0.1;
				camx=camx+0.05;
				ang=-t;
			}
		}
	}
	function onkeyup(e) {
		if (e.keyCode in map) {
			map[e.keyCode] = false;
		}
		
	}

function reload(){
	window.location.reload();
}