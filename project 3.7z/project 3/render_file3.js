function configureTexture( image ) {
    texture = gl.createTexture();
    gl.bindTexture( gl.TEXTURE_2D, texture );
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGBA,gl.RGBA, gl.UNSIGNED_BYTE, image );
    gl.generateMipmap( gl.TEXTURE_2D );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR );
    	 gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );

    //gl.uniform1i(gl.getUniformLocation(program, "texture0"), 0);
}
function configureTexture1( image1 ) {
    texture1 = gl.createTexture();
    gl.bindTexture( gl.TEXTURE_2D, texture1 );
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGBA,gl.RGBA, gl.UNSIGNED_BYTE, image1 );
    gl.generateMipmap( gl.TEXTURE_2D );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR );
    	 gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );

    //gl.uniform1i(gl.getUniformLocation(program, "texture0"), 0);
}
function configureTexture2( image2 ) {
    texture2 = gl.createTexture();
    gl.bindTexture( gl.TEXTURE_2D, texture2 );
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGBA,gl.RGBA, gl.UNSIGNED_BYTE, image2 );
    gl.generateMipmap( gl.TEXTURE_2D );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR );
    	 gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );

    //gl.uniform1i(gl.getUniformLocation(program, "texture0"), 0);
}


function render() {
	gl.clear( gl.COLOR_BUFFER_BIT);
	
	var sphere_loc=gl.getUniformLocation(program,'sphere_mov');
	var camLoc=gl.getUniformLocation(program,'camera');
	var cam=lookAt([camx,camy,camz],[a,b,c],[0,1,0]);
	var thetaLoc=gl.getUniformLocation(program,"theta");
	var angle=[0,0];
	gl.uniform2fv(thetaLoc, angle);
	gl.uniformMatrix4fv(camLoc,false,flatten(cam));
	
	var clipLoc= gl.getUniformLocation(program,'clip');
	var clip=ortho(left,right,bottom,to,near,far);
	gl.uniformMatrix4fv(clipLoc,false,flatten(clip));
	
	var persLoc=gl.getUniformLocation(program,'pers');
	var pers=perspective(50,1.0,-5,10);
	gl.uniformMatrix4fv(persLoc, false, flatten(pers));
	gl.uniform4fv(lightPositionLoc,flatten(lightPosition));   
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	////sphere//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(carpoints), gl.STATIC_DRAW );
	gl.uniform4fv(sphere_loc, [spherex,0,spherez,0.0]);
    angle=[ang,0];
	gl.uniform2fv(thetaLoc, angle);
    //gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    //gl.bufferData( gl.ARRAY_BUFFER, flatten(carcolors), gl.STATIC_DRAW );
	
	gl.activeTexture(gl.TEXTURE2);
	gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer1 );
	gl.bindTexture(gl.TEXTURE_2D,texture2);
	//gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW );
	gl.uniform1i(gl.getUniformLocation(program, "texture2"), 2);
	gl.uniform1i(gl.getUniformLocation(program, "flag"), 2);
	
	gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId3 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals1), gl.STATIC_DRAW );
	gl.uniform4fv(ambProdLoc,flatten(ambientProduct1));
    gl.uniform4fv(difProdLoc,flatten(diffuseProduct1));
    gl.uniform4fv(specProdLoc,flatten(specularProduct1));
    gl.uniform1f(shininessLoc,materialShininess1);	
    
	gl.drawArrays( gl.TRIANGLES, 0, carpoints.length);
	if(flag==1){
		end();
	}
    check(spherez, spherex-l,spherex+l, spherex);
	gl.bindTexture(gl.TEXTURE_2D, null);
	////wall/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
	gl.bufferData( gl.ARRAY_BUFFER, flatten(wall), gl.STATIC_DRAW );
	gl.uniform4fv(sphere_loc, [0,0.0,0,0.0])
	
	gl.activeTexture(gl.TEXTURE1);
	
	gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer1 );
	gl.bindTexture(gl.TEXTURE_2D,texture);
	//gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW );
	gl.uniform1i(gl.getUniformLocation(program, "texture1"), 1);
	gl.uniform1i(gl.getUniformLocation(program, "flag"), 1);
	//gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
	//gl.bufferData( gl.ARRAY_BUFFER, flatten(wallcolors), gl.STATIC_DRAW );
	
	gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId2 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals2), gl.STATIC_DRAW );
	gl.uniform4fv(ambProdLoc,flatten(ambientProduct2));
    gl.uniform4fv(difProdLoc,flatten(diffuseProduct2));
    gl.uniform4fv(specProdLoc,flatten(specularProduct2));
    gl.uniform1f(shininessLoc,materialShininess2);
    
	gl.drawArrays( gl.TRIANGLES, 0, wall.length);
	gl.bindTexture(gl.TEXTURE_2D, null);
    gl.bindBuffer( gl.ARRAY_BUFFER, null );
	
	/////////////////////////////////////////////////////////////////////////////////
	gl.uniform4fv(sphere_loc, [0.0,0.01,0.0,0.0]);
	
	gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(points2), gl.STATIC_DRAW );
	
	//gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    //gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );
	
	gl.activeTexture(gl.TEXTURE0);
	gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer );
	gl.bindTexture(gl.TEXTURE_2D,texture1);
	gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray1), gl.STATIC_DRAW );
	gl.uniform1i(gl.getUniformLocation(program, "texture0"), 0);
	gl.uniform1i(gl.getUniformLocation(program, "flag"), 0);
	
	gl.bindBuffer( gl.ARRAY_BUFFER, nbufferId1 );
    gl.bufferData( gl.ARRAY_BUFFER,flatten(normals3), gl.STATIC_DRAW );
	gl.uniform4fv(ambProdLoc,flatten(ambientProduct3));
    gl.uniform4fv(difProdLoc,flatten(diffuseProduct3));
    gl.uniform4fv(specProdLoc,flatten(specularProduct3));
    gl.uniform1f(shininessLoc,materialShininess3);
   
	gl.drawArrays( gl.TRIANGLES, 0, points2.length);
	gl.bindTexture(gl.TEXTURE_2D, null);
	
	requestAnimFrame(render);
}