function makewall(c){
	////wall left////
	wall.push(c[0]);
	texCoordsArray.push(texCoord[0]);
	wall.push(c[1]);
	texCoordsArray.push(texCoord[1]);
	wall.push(c[2]);
	texCoordsArray.push(texCoord[2]);
	wall.push(c[2]);
	texCoordsArray.push(texCoord[2]);
	wall.push(c[3]);
	texCoordsArray.push(texCoord[3]);
	wall.push(c[0]);
	texCoordsArray.push(texCoord[0]);
	normals2.push(c[0][0],c[0][1], c[0][2], 0.0);
	normals2.push(c[1][0],c[1][1], c[1][2], 0.0);
	normals2.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals2.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals2.push(c[3][0],c[3][1], c[3][2], 0.0);
	normals2.push(c[0][0],c[0][1], c[0][2], 0.0);
	////wall right///
	wall.push(c[7]);
	wall.push(c[6]);
	wall.push(c[5]);
	wall.push(c[5]);
	wall.push(c[4]);
	wall.push(c[7]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[1]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[3]);
	texCoordsArray.push(texCoord[0]);
	normals2.push(c[7][0],c[7][1], c[7][2], 0.0);
	normals2.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals2.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals2.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals2.push(c[4][0],c[4][1], c[4][2], 0.0);
	normals2.push(c[7][0],c[7][1], c[7][2], 0.0);
	
	////base
	
	wall.push(base[0]);
	wall.push(base[1]);
	wall.push(base[2]);
	wall.push(base[2]);
	wall.push(base[3]);
	wall.push(base[0]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[1]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[3]);
	texCoordsArray.push(texCoord[0]);
	normals2.push(base[0][0],base[0][1], base[0][2], 0.0);
	normals2.push(base[1][0],base[1][1], base[1][2], 0.0);
	normals2.push(base[2][0],base[2][1], base[2][2], 0.0);
	normals2.push(base[2][0],base[2][1], base[2][2], 0.0);
	normals2.push(base[3][0],base[3][1], base[3][2], 0.0);
	normals2.push(base[0][0],base[0][1], base[0][2], 0.0);
	
	////roof
	wall.push(c[2]);
	wall.push(c[1]);
	wall.push(c[5]);
	wall.push(c[5]);
	wall.push(c[6]);
	wall.push(c[2]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[1]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[3]);
	texCoordsArray.push(texCoord[0]);
	
	normals2.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals2.push(c[1][0],c[1][1], c[1][2], 0.0);
	normals2.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals2.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals2.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals2.push(c[2][0],c[2][1], c[2][2], 0.0);
	///wall back
	wall.push(c[3]);
	wall.push(c[2]);
	wall.push(c[6]);
	wall.push(c[6]);
	wall.push(c[7]);
	wall.push(c[3]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[1]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[2]);
	texCoordsArray.push(texCoord[3]);
	texCoordsArray.push(texCoord[0]);
	
	normals2.push(c[3][0],c[3][1], c[3][2], 0.0);
	normals2.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals2.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals2.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals2.push(c[7][0],c[7][1], c[7][2], 0.0);
	normals2.push(c[3][0],c[3][1], c[3][2], 0.0);
	////left strip//
	/*wall.push(c[8]);
	wall.push(c[9]);
	wall.push(c[10]);
	wall.push(c[9]);
	wall.push(c[10]);
	wall.push(c[11]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	normals2.push(c[8][0],c[8][1], c[8][2], 0.0);
	normals2.push(c[9][0],c[9][1], c[9][2], 0.0);
	normals2.push(c[10][0],c[10][1], c[10][2], 0.0);
	normals2.push(c[9][0],c[9][1], c[9][2], 0.0);
	normals2.push(c[10][0],c[10][1], c[10][2], 0.0);
	normals2.push(c[11][0],c[11][1], c[11][2], 0.0);
	////right strip
	wall.push(c[12]);
	wall.push(c[13]);
	wall.push(c[14]);
	wall.push(c[13]);
	wall.push(c[14]);
	wall.push(c[15]);
	
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	texCoordsArray.push(texCoord[0]);
	normals2.push(c[12][0],c[12][1], c[12][2], 0.0);
	normals2.push(c[13][0],c[13][1], c[13][2], 0.0);
	normals2.push(c[14][0],c[14][1], c[14][2], 0.0);
	normals2.push(c[13][0],c[13][1], c[13][2], 0.0);
	normals2.push(c[14][0],c[14][1], c[14][2], 0.0);
	normals2.push(c[15][0],c[15][1], c[15][2], 0.0);
	*/
	//////////////////////////////////////////////////////////////////////////
	///wall left
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	////wall right
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	
	////base
	wallcolors.push([0.0,1.0,0.0,0.5]);
	wallcolors.push([0.0,1.0,0.0,0.5]);
	wallcolors.push([0.0,1.0,0.0,0.5]);
	wallcolors.push([0.0,1.0,0.0,0.5]);
	wallcolors.push([0.0,1.0,0.0,0.5]);
	wallcolors.push([0.0,1.0,0.0,0.5]);
	////roof
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	////wall back////
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	wallcolors.push([1.0,1.0,1.0,0.5]);
	////strip right
	wallcolors.push(green);
	wallcolors.push(green);
	wallcolors.push(green);
	wallcolors.push(green);
	wallcolors.push(green);
	wallcolors.push(green);
	
}
function car(c){
	////front
	carpoints.push(c[0]);
	carpoints.push(c[1]);
	carpoints.push(c[2]);
	carpoints.push(c[2]);
	carpoints.push(c[3]);
	carpoints.push(c[0]);
	
	normals3.push(c[0][0],c[0][1], c[0][2], 0.0);
	normals3.push(c[1][0],c[1][1], c[1][2], 0.0);
	normals3.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals3.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals3.push(c[3][0],c[3][1], c[3][2], 0.0);
	normals3.push(c[0][0],c[0][1], c[0][2], 0.0);
	
	cartex.push(texCoord[0]);
	cartex.push(texCoord[1]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[3]);
	cartex.push(texCoord[0]);
	////back///
	carpoints.push(c[4]);
	carpoints.push(c[5]);
	carpoints.push(c[6]);
	carpoints.push(c[6]);
	carpoints.push(c[7]);
	carpoints.push(c[4]);
	
	normals3.push(c[4][0],c[4][1], c[4][2], 0.0);
	normals3.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[7][0],c[7][1], c[7][2], 0.0);
	normals3.push(c[4][0],c[4][1], c[4][2], 0.0);
	
	
	cartex.push(texCoord[0]);
	cartex.push(texCoord[1]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[3]);
	cartex.push(texCoord[0]);
	////left
	carpoints.push(c[0]);
	carpoints.push(c[1]);
	carpoints.push(c[4]);
	carpoints.push(c[4]);
	carpoints.push(c[5]);
	carpoints.push(c[1]);
	normals3.push(c[0][0],c[0][1], c[0][2], 0.0);
	normals3.push(c[1][0],c[1][1], c[1][2], 0.0);
	normals3.push(c[4][0],c[4][1], c[4][2], 0.0);
	normals3.push(c[4][0],c[4][1], c[4][2], 0.0);
	normals3.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals3.push(c[1][0],c[1][1], c[1][2], 0.0);
	
	cartex.push(texCoord[0]);
	cartex.push(texCoord[1]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[3]);
	cartex.push(texCoord[0]);
	////right
	carpoints.push(c[2]);
	carpoints.push(c[3]);
	carpoints.push(c[6]);
	carpoints.push(c[6]);
	carpoints.push(c[7]);
	carpoints.push(c[3]);
	
	normals3.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals3.push(c[3][0],c[3][1], c[3][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[7][0],c[7][1], c[7][2], 0.0);
	normals3.push(c[3][0],c[3][1], c[3][2], 0.0);
	
	cartex.push(texCoord[0]);
	cartex.push(texCoord[1]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[3]);
	cartex.push(texCoord[0]);
	////car top
	
	carpoints.push(c[1]);
	carpoints.push(c[2]);
	carpoints.push(c[6]);
	carpoints.push(c[6]);
	carpoints.push(c[5]);
	carpoints.push(c[1]);
	
	normals3.push(c[1][0],c[1][1], c[1][2], 0.0);
	normals3.push(c[2][0],c[2][1], c[2][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[6][0],c[6][1], c[6][2], 0.0);
	normals3.push(c[5][0],c[5][1], c[5][2], 0.0);
	normals3.push(c[1][0],c[1][1], c[1][2], 0.0);
	
	cartex.push(texCoord[0]);
	cartex.push(texCoord[1]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[2]);
	cartex.push(texCoord[3]);
	cartex.push(texCoord[0]);
	///////////////////////////////////////////////////////////
	
	
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	////wall front
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	carcolors.push([1.0,1.0,1.0,0.5]);
	
	////base
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	////roof
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
	carcolors.push(green);
}
